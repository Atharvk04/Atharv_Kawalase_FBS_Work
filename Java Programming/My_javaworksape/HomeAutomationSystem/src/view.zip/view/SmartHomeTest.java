package view;

import view.HomeView;

public class SmartHomeTest 
{

    public static void main(String[] args) 
    {
        HomeView homeView = new HomeView();
        homeView.start();
    }
}
