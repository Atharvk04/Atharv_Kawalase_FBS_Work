package view;

import java.util.Scanner;

public class HomeView {

    private Scanner sc = new Scanner(System.in);

    // ---------------- APPLICATION START ----------------
    public void start() {

        int choice;

        do {
            choice = showMainMenu();

            switch (choice) {

                case 1:
                    addRoomView();
                    break;

                case 2:
                    addDeviceView();
                    break;

                case 3:
                    turnOnDeviceView();
                    break;

                case 4:
                    turnOffDeviceView();
                    break;

                case 5:
                    showRoomStatusView();
                    break;

                case 6:
                    removeDeviceView();
                    break;

                case 7:
                    displayDetailsView();   // ✅ NEW DISPLAY OPTION
                    break;

                case 8:
                    display("Thank you! Exiting application.");
                    break;

                default:
                    display("Invalid choice. Please try again.");
            }

        } while (choice != 8);
    }

    // ---------------- MAIN MENU ----------------
    int showMainMenu() {
        display("\n====== SMART HOME MENU ======");
        display("1. Add Room");
        display("2. Add Device");
        display("3. Turn ON Device");
        display("4. Turn OFF Device");
        display("5. Show Room Status");
        display("6. Remove Device");
        display("7. Display Details");   // ✅ NEW
        display("8. Exit");
        System.out.print("Enter your choice: ");

        return sc.nextInt();
    }

    // ---------------- ADD ROOM ----------------
    private void addRoomView() {

        display("\n--- ADD ROOM ---");

        System.out.print("Enter Room ID: ");
        int roomId = sc.nextInt();

        int roomType = selectRoomType();

        display("Room added successfully (RoomId=" + roomId + ", RoomType=" + roomType + ")");
    }

    // ---------------- ADD DEVICE ----------------
    private void addDeviceView() {

        System.out.print("Enter Room ID: ");
        int roomId = sc.nextInt();

        int deviceType = selectDeviceType();

        System.out.print("Enter Device ID: ");
        int deviceId = sc.nextInt();

        display("Device added successfully (RoomId=" + roomId +
                ", DeviceId=" + deviceId + ", DeviceType=" + deviceType + ")");
    }

    // ---------------- REMOVE DEVICE ----------------
    private void removeDeviceView() {

        display("\n--- REMOVE DEVICE ---");

        System.out.print("Enter Room ID: ");
        int roomId = sc.nextInt();

        int deviceType = selectDeviceType();

        System.out.print("Enter Device ID to remove: ");
        int deviceId = sc.nextInt();

        display("Device removed successfully (RoomId=" + roomId +
                ", DeviceId=" + deviceId + ", DeviceType=" + deviceType + ")");
    }

    // ---------------- TURN ON DEVICE ----------------
    private void turnOnDeviceView() {

        display("\n--- TURN ON DEVICE ---");

        int roomType = selectRoomType();
        int deviceType = selectDeviceType();

        display("Device turned ON (RoomType=" + roomType + ", DeviceType=" + deviceType + ")");
    }

    // ---------------- TURN OFF DEVICE ----------------
    private void turnOffDeviceView() {

        display("\n--- TURN OFF DEVICE ---");

        int roomType = selectRoomType();
        int deviceType = selectDeviceType();

        display("Device turned OFF (RoomType=" + roomType + ", DeviceType=" + deviceType + ")");
    }

    // ---------------- SHOW ROOM STATUS ----------------
    private void showRoomStatusView() {

        display("\n--- ROOM STATUS ---");

        int roomType = selectRoomType();

        display("Showing status for RoomType=" + roomType);
    }

    // ---------------- DISPLAY DETAILS ----------------
    private void displayDetailsView() {

        display("\n--- DISPLAY DETAILS ---");
        display("Rooms and Devices information will be displayed here.");
        display("(Controller / Model integration pending)");
    }

    // ---------------- ROOM OPTIONS ----------------
    private int selectRoomType() {

        display("\nSelect Room Type:");
        display("1. Hall");
        display("2. Bedroom");
        display("3. Kitchen");
        display("4. Dining Hall");
        display("5. Corridor");
        display("6. Washroom");
        System.out.print("Enter room choice: ");

        return sc.nextInt();
    }

    // ---------------- DEVICE OPTIONS ----------------
    private int selectDeviceType() {

        display("\nSelect Device Type:");
        display("1. Light");
        display("2. Fan");
        display("3. AC");
        display("4. TV");
        display("5. Refrigerator");
        display("6. Washing Machine");
        System.out.print("Enter device choice: ");

        return sc.nextInt();
    }

    // ---------------- COMMON DISPLAY METHOD ----------------
    private void display(String message) {
        System.out.println(message);
    }
}
